import React from "react"

const home = () => {
  return <h1>welcome to hooks </h1>
}

export default home
